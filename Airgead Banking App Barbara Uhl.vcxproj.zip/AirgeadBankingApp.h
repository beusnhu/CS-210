#ifndef AIRGEADBANKINGAPP_H_
#define AIRGEADBANKINGAPP_H_

class AirgeadBankingApp {
public:
	AirgeadBankingApp();
	virtual ~AirgeadBankingApp();
	
	void printDisplay(); // output details on screen

	//get user input
	void getValues(float* initialInvestment, float* monthlyDeposit, float* AnnualInterest, float* months, float* years);

	// output table one
	void displayTableOne(float initialInvestment, float monthlyDeposit, float AnnualInterest, float months, float years);

	// output second table
	void displayTableTwo(float initialInvestment, float monthlyDeposit, float AnnualInterest, float months, float years);
};

#endif 

