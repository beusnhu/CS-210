/*
 * Barbara Uhl
 *
 * October 3 , 2021
 *
 * CS 210
 */

#pragma once
#include <iostream> // used to get stream size
#include <iomanip> 
#include "AirgeadBankingApp.h"
using namespace std;


int main() { // main function
    float initialInvestment, monthlyDeposit, AnnualInterest, months, years;


    AirgeadBankingApp airgeadbankingapp;
    airgeadbankingapp.printDisplay();
    cout << "Press any key to continue."; // output
    cin.ignore(); // clear buffer before taking new

    airgeadbankingapp.getValues(&initialInvestment, &monthlyDeposit, &AnnualInterest, &months, &years);
    months = years * 12;

    cout << "Press any key to continue."; // output 
    cin.ignore(); // clear buffer before taking new

    airgeadbankingapp.displayTableOne(initialInvestment, monthlyDeposit, AnnualInterest, months, years);

    cout << "Press any key to continue."; // output
    cin.ignore(); // clear buffer before taking new

    airgeadbankingapp.displayTableTwo(initialInvestment, monthlyDeposit, AnnualInterest, months, years);

    return 0;
}
