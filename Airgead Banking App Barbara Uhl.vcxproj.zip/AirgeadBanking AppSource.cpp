#include <iostream> // used to get stream size
#include <iomanip>
using namespace std;
#include "AirgeadBankingApp.h"

AirgeadBankingApp::AirgeadBankingApp() { // constructor
}

AirgeadBankingApp::~AirgeadBankingApp() { // destructor
}

// Output menu/required items
void AirgeadBankingApp::printDisplay() {

	cout << "************\n";
	cout << "**** Data Input ****\n";
	cout << "Initial Investment Amount: \n";
	cout << "Monthly Deposit: \n";
	cout << "Annual Interest: \n";
	cout << "Number of years: \n";

}

 // Get input from user
void AirgeadBankingApp::getValues(float* initialInvestment, float* monthlyDeposit, float* AnnualInterest, float* months, float* years) {

	float temp;
	cout << "************\n";
	cout << "**** Data Input ****\n";
	cout << "Initial Investment Amount: $";
	cin >> temp;
	*initialInvestment = temp;
	cout << "Monthly Deposit: $";
	cin >> temp;
	*monthlyDeposit = temp;
	cout << "Annual Interest: %";
	cin >> temp;
	*AnnualInterest = temp;
	cout << "Number of years: ";
	cin >> temp;
	*years = temp;

}

// Output the first table
void AirgeadBankingApp::displayTableOne(float initialInvestment, float monthlyDeposit, float AnnualInterest, float months, float years) {

	float totalAmount, interestAmount;

	totalAmount = initialInvestment;

	cout << "\nBalance and Interest Without Additional Monthly Deposits\n"; // table header
	cout << "==============================================================\n"; // table header
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n"; // table header
	cout << "--------------------------------------------------------------\n"; // table header
	for (int i = 0; i < years; i++) {
		interestAmount = (totalAmount) * ((AnnualInterest / 100)); // calculate interestAmount
		totalAmount = totalAmount + interestAmount; // calculate totalAmount
		// cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << intAmt << "\n";
		cout << fixed;
		cout << setprecision(2);
		cout << (i + 1);
		cout.width(25);
		cout << "$" << totalAmount;
		cout.width(25);
		cout << "$" << interestAmount;
		cout << endl;
	}



}

// Output the second table
void AirgeadBankingApp::displayTableTwo(float initialInvestment, float monthlyDeposit, float AnnualInterest, float months, float years) {

	float totalAmount, interestAmount, yearTotalInterest;

	totalAmount = initialInvestment;


	cout << "\n\nBalance and Interest With Additional Monthly Deposits\n"; //  table header
	cout << "==============================================================\n"; // table header
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";  // table header
	cout << "--------------------------------------------------------------\n"; // table header
	for (int i = 0; i < years; i++) {
		yearTotalInterest = 0;
		for (int j = 0; j < 12; j++) {
			interestAmount = (totalAmount + monthlyDeposit) * ((AnnualInterest / 100) / 12); // calculate interestAmount
			yearTotalInterest = yearTotalInterest + interestAmount; // calculate yearTotalInterest
			totalAmount = totalAmount + monthlyDeposit + interestAmount; // calculate totalAmount
		}

		cout << fixed;
		cout << setprecision(2);
		cout << (i + 1);
		cout.width(25);
		setprecision(2);
		cout << "$" << totalAmount; // output totalAmount

		cout.width(25);
		cout << "$" << yearTotalInterest; // output yearTotalInterest
		cout << endl;
	}

}
